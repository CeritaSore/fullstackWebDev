<!--================ Start About Us Area =================-->
<section class="about_area section_gap">
    <div class="container">
        <div class="row justify-content-start align-items-center">
            <div class="col-lg-5">
                <div class="about_img">
                    <img class="" src="img/about-us.png" alt="">
                </div>
            </div>

            <div class="offset-lg-1 col-lg-5">
                <div class="main_title text-left">
                    <h2>Yuk <br>
                        Kenalan <br>
                    </h2>
                    <p>
                        Fajar septianto adalah seorang mahasiswa Sekolah Tinggi Teknologi Nurul Fikri angkatan 2021. 
                    </p>
                    <p>
                        Suka baca komik yang gak populer di kalangan umum. mendalami isi dari cerita. Senang belajar jaringan komputer dan cloud computing.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!--================ End About Us Area =================-->